
# python-anopi
## General
### This is a library for the implementation of the AnpPi Header in a python environment
## Installation
```
pip install python-anopi
```